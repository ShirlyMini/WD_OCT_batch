# set
# collection of datatypes  which is unordered and unindexed
# curly bracket{}
# changeable or mutable

# create

# set1={"apple", "orange", "cherry", "banana"}
# print(set1)

# empty set
# myset=set()
# print(myset)
# print(type(myset))
# # myset= {} # dict
# # print(myset)
# # print(type(myset)) # dict

# accessing element

# set1={"apple", "orange", "cherry", "banana"}
# print(set1[0]) #TypeError: 'set' object is not subscriptable
# for i in set1:
#     if "orange" == i:
#         print(i)

# indirect way
# list1=list(set1)
# print(list1)
# print(list1[-2])

# add/ update set

# set1={"apple", "orange", "cherry", "banana"}
#
# set1.add("kiwi") # single item
# print(set1)
#
# set1.update({"kiwi", "dragon frt"}) # multiple item
# print(set1)
#
# print(len(set1))

# remove item

# set1={"apple", "orange", "cherry", "banana"}
# set1.pop()
# print(set1)
# set1.remove("orange")
# print(set1)
# set1.discard("cherry")
# print(set1)


# with non exsisting item
# set1.remove("kiwi") #KeyError: 'kiwi'
# print(set1)

# set1.discard("kiwi")
# print(set1) # no error

# set1.clear()
# print(set1) # empty set

# copy
# set1={"apple", "orange", "cherry", "banana"}
# print(f"set1: {set1} id : {id(set1)}")
# set2=set1
# print(f"set2: {set2} id : {id(set2)}")
#
# #set2.remove("apple")
# print(f"set1: {set1} id : {id(set1)}")
# print(f"set2: {set2} id : {id(set2)}") # shallow copy

#set3=set(set1) # deep copy
# print(f"set3: {set3} id : {id(set3)}")
# set3.remove("apple")
# print(f"set1: {set1} id : {id(set1)}")
# print(f"set3: {set3} id : {id(set3)}")

# set4=set1.copy() # deep copy
# print(f"set4: {set4} id : {id(set4)}")
# set4.remove("apple")
# print(f"set1: {set1} id : {id(set1)}")
# print(f"set4: {set4} id : {id(set4)}")

# join / comine
set1={"apple", "orange", "cherry", "banana"}
set2={10,20,30}
set4={10,20,40}

set3=set1.union(set2)
print(set3)
# print(set2+set1) # TypeError: unsupported operand type(s) for +: 'set' and 'set'
print(set4.intersection(set2))


# with duplicate
s1={1,2,3,1,2,3}
print(s1)

s1=[1,2,3,1,2,3]
print(s1)

s1=(1,2,3,1,2,3)
print(s1)
