# searching substring
# str1="Welcome To Python"
# print(str1.count("o"))
# print(str1.count("Python"))

# converting the string
# str1="welcome to python"
# print(str1.capitalize())
# str2=str1.capitalize()
# print(str2)
# print(str1.title())
# print(str1)
# print(str1.upper())
# str3=str1.upper()
# print(str3.lower())

str1="Welcome To Python"
print(str1.swapcase())

print(str1.replace("Python", "Java"))
print(str1)
