# pack1--> mod1, mod2--> func1, func2---> access it in client files
# import pack1---> cannot access modules or function inside the pcak1 package
# from pack1 import mod1, mod2
# #from pack1 import mod2
# mod1.display()
# mod2.show()

from pack1.mod1 import display
from pack1.mod2 import display, show

display()
show()
