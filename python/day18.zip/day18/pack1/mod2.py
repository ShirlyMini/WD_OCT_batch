def show():
    print("func show in mod2")

def display():
    print("func display in mod2")