def display():
    print("func display in mod1")