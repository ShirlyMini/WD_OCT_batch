# jumping statement
# break
# continue - skip

# skip number divisible by 3
# for var in range(1,11):# 1,2,..10
#
#     if var%3==0:
#         continue
#     print(var)

#skip number divisible by 5
for var in range(1, 11):  # 1,2,..10
    print(var)
    if var % 5 == 0:
        break

