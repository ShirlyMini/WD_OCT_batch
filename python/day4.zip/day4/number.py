# numbers - int and float
# a=5
# print(type(a))
# b=float(a)
# print(type(b))
# print(a, b)
# c=int(b)
# print(type(c))
# print(a, b, c)

# a="5"
# print(type(a))
# #print(a+4) # TypeError: can only concatenate str (not "int") to str
# b=int(a)
# print(type(b))
# print(b+4)
#
# print(max(100,20,30))
# print(min(100,20,30))

# user input
# num1=input("enter number1")
# num2=input("enter number2")
# print(type(num1))
# print(type(num2))
# print(num1+num2)

# ex 1
num1=int(input("enter number1"))
num2=int(input("enter number2"))

print(num1+num2)
# ex 2
num1=input("enter number1")
num2=input("enter number2")

print(int(num1)+int(num2))