#list() ---> []
# list1 = list((1,2,3,4,5))
# print(type(list1))
#tuple1=tuple((6,7,8,9,10))
# set1=set(("x","y","z"))
#print(type(tuple1))
# print(type(set1))
#
#
# sampleList = [10, 20, 30, 40, 50]
# print(sampleList[-2])
# print(sampleList[2:-2])
# print(sampleList[1:-2])
# print(sampleList[-2:2:-1]) # start -2=40 # ends n-(-1)2+1=3=40
# print(sampleList[-3:0:-1]) # star -3=30 # ends n+1=0+1 =20
# print(sampleList[-3:-1:-1]) # star -3=30 # ends n+1=0+1 =20
# print(sampleList[-3::-1]) # star -3=30 # ends n+1=0+1 =20
#
# print(sampleList[-4:-1])
#
# aList = [4, 8, 12, 16]
# aList[1:4] = [20, 24, 28]
# # [1,2,3] = [20, 24, 28]
# print(aList)
str1 = "my isname isisis veenais isis newname";
sub = "is"
print(str1.count(sub,4))