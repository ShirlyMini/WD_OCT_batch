# overriding- not applicable
# overloading

class parent:
    def func(self,*a):
        print("func of parent1")

obj=parent()
obj.func(10,20,30)
