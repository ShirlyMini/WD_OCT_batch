def add(n1,n2):
    print("add from mod2 ",n1+n2)

def multiply(n1,n2):
    print("multiply from mod2",n1*n2)


class animal:
    def display(self):
        print("this is cat")

class A:
    def display(self):
        print("this is class A module 2")