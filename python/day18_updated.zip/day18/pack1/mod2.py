def show():
    print("func show in mod2")

def display():
    print("func display in mod2")

class animal:
    def display(self):
        print("this is cat")

class A:
    def display(self):
        print("this is class A module 2")