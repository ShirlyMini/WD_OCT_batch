# class & object

# class is blueprint, logical entity, template[resume]
# no mem alloc

# object
# accuire all properties of class
# physical entity
# accqure space in mem loc

# resume[class]
# name
# age
# qua
# presonal infor
# projcet

# sutdent1[object]
# pooja
# 21
# BE
# per1
# project1

# func vs method
# method - func inside class
# func = func outside class

# class myclass:
#     print("hello myclass")
#
# print(myclass())

# class myclass:
#     pass # do nothing keyword
#
# print(myclass())
#
# def myfunc():
#     pass
# print(myfunc())

# class with methods

class myclass:
    def myfunc1(self):
        print("myfunc1")

obj=myclass()
obj.myfunc1()

