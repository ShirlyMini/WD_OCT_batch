import file1
print("__name__ from file 2", __name__)
file1.func1()